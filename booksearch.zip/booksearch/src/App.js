// import logo from './logo.svg';
import './App.css';
import Search from './components/Search';
import './components/style.css';

function App() {
  return (
   <>
     <Search/>
   </>
  );
}

export default App;
